GRNET_HOME=`pwd`

# Chamfer Distance
cd $GRNET_HOME/extensions/chamfer_dist
python setup.py install --user
